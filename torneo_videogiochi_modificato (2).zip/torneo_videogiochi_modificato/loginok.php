<!DOCTYPE html>
<form action="index.php" method = "post"></form>
<?php
        session_start();
        if (!isset($_SESSION['database'])) {
            header("Location: index.php");
        }
    ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Effettuato</title>
</head>
<body>
    Identificazione utente avvenuta con successo<br>
    Benvenuto nell'area riservata<br>
</body>
</html>