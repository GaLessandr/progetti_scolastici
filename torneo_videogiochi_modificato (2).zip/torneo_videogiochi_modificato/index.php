<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Torneo videogiochi</title>
</head>
<body>
<form action="prenota.php" method="post">
        <?php
            $host = "localhost";
            $username = "root";
            $password = "";
            $db_nome = "torneovg";
            
            $conn = new mysqli($host, $username, $password, $db_nome);
            if ($conn->connect_errno) {
                echo "Impossibile connetersi al server" . $conn->connect_error . "\n";
                exit;
            }

            echo "<h2>Benvenuto al torneo di Videogiochi!</h2>";
            $conn->close();
        ?>
</form>
    <li><a href="iscrizione.php">Iscriviti a un Torneo</a></li>
    <li><a href="elenco.php">Visualizza iscritti</a></li>
    <li><a href="aggiungi_gioco.php">Aggiungi nuovo gioco</a></li>     

</body>
</html>