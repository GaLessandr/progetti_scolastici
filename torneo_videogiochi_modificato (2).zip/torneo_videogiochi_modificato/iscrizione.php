<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method = "post">
    <div>
        <label>Nome e Cognome:</label>
        <input type="text" name = "nome" required><br>
        <label>Classe:</label>
        <input type="text" name = "classe" required><br>
        <select name="gioco">
            <?php
                $host = "localhost";
                $username = "root";
                $password = "";
                $db_nome = "torneovg";

                $conn = new mysqli($host, $username, $password, $db_nome);
                if ($conn->connect_errno) {
                    echo "Impossibile connetersi al server" . $conn->connect_error . "\n";
                    exit;
                }

                $tab_name = "giochi";
                $sql = "SELECT * FROM $tab_name";
                $result = $conn->query($sql);

                while($row = $result->fetch_assoc()){
                    echo "<option value = \"".$row['id']."\">".$row['nome']."</option> \n";
                }
                $result->free();
                $conn->close();
            ?>

        </select>
    </div>
    <input type="submit" name = "iscrizione" value = "iscrizione">    
        <?php
        if ($_SERVER['REQUEST_METHOD'] === "POST"){
            $host = "localhost";
            $username = "root";
            $password = "";
            $db_nome = "torneovg";
    
            $conn = new mysqli($host, $username, $password, $db_nome);
            if ($conn->connect_errno) {
            exit;
            }
            if (isset($_POST['iscrizione'])) {
                $nome_studente = isset($_POST['nome']) ? $_POST['nome'] : '';
                $cognome_studente = isset($_POST['cognome']) ? $_POST['cognome'] : '';
                $classe_studente = isset($_POST['classe']) ? $_POST['classe'] : '';
                $gioco = isset($_POST['gioco']) ? $_POST['gioco'] : '';

                $tab_name = "iscritti";
                $sql = "INSERT INTO $tab_name (nome_studente, classe, id_gioco)";
                $sql .= " VALUES ('$nome_studente', '$classe_studente', '$gioco')";



                $result = $conn->query($sql);
}
                if ($result) {
                    echo "Registrazione effettuata con successo!<br>";
                } else {
                    echo "Errore: " . $sql . "<br>" . $conn->error;
                }
            }
        ?>
        <br>Ritorna alla pagina <a href="index.php">iniziale</a>
        </form>
    </body>
</html>