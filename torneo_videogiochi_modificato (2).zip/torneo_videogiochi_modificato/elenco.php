<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Elenco Giochi</title>
</head>
<body>
    <h2>Elenco Giochi</h2>
    <a href="elenco.php?ordina=nome">Ordina per Nome</a> | 
    <a href="elenco.php?ordina=classe">Ordina per Classe</a>
    <br><br>
    <?php
    $conn = new mysqli("localhost", "root", "", "torneo");
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }
    $ordine = "nome";
    if (isset($_GET['ordina']) && in_array($_GET['ordina'], ['nome', 'classe'])) {
        $ordine = $_GET['ordina'];
    }
    $sql = "SELECT * FROM giochi ORDER BY $ordine";
    $result = $conn->query($sql);
    echo "<table border='1'><tr><th>Nome</th><th>Classe</th><th>Azioni</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row['nome']."</td><td>".$row['classe']."</td>";
        echo "<td><a href='elimina_gioco.php?id=".$row['id']."'>Elimina</a></td></tr>";
    }
    echo "</table>";
    $conn->close();
    ?>
</body>
</html>
