<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form action="index.php" method="post"></form>
    <h2>Accesso all'area riservata</h2>
    <form action="controllalogin.php" method= "post">
        <label>Host:</label>
        <input type="text" name = "host"><br>
        <label>NomeUtente:</label>
        <input type="text" name="nome" required><br>
        <label>Password:</label>
        <input type="password" name="Password"><br>
        <label>Database:</label>
        <input type="text" name = "database">
        <br><input type="submit" name="Invio" value="Login">
        <input type="submit" name="Cancella" value="Annulla">
    </form>
</body>
<br><a href="index.php">Pagina iniziale</a>
</html>