<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
if (isset($_GET['id'])) {
    $conn = new mysqli("localhost", "root", "", "torneo");
    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }
    $id = intval($_GET['id']);
    $sql = "DELETE FROM giochi WHERE id=$id";
    $conn->query($sql);
    $conn->close();
}
header("Location: elenco.php");
exit();
?>
