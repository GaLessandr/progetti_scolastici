<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ControllaLogin</title>
</head>
<body>
    <form method = "post">
        <?php
            $host = isset($_POST['host']) ? $_POST['host'] : '';
            $username = isset($_POST['nome']) ? $_POST['nome'] : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $db_nome = isset($_POST['database']) ? $_POST['database'] : '';
            $tab_name = "giochi";
            $controllo = false;

            $conn = new mysqli($host, $username, $password, $db_nome);
            if ($conn->connect_errno) {
                echo "Errore di connessione: " . $conn->connect_error;
                exit;
            }

            if (isset($_POST['Invio'])) {

                $sql = "SELECT * FROM $tab_name";
                $result = $conn->query($sql);
                $conta = $result->num_rows;
                if ($conta >= 1 ) {
                    $row = $result->fetch_assoc();
                    $passc = $row['password'];
                    if (password_verify($password, $passc)) {
                        $controllo = true;
                    }
                }

                if ($controllo) {
                    session_start();
                    $_SESSION['nomes'] = $username;
                    $_SESSION['password'] = $password;
                    header("Location: Loginok.php");
                } else {
                    echo "<h2>Login fallito Email o password errati</h2>";
                    echo "torna a pagina di <a href=\"Login.php\">login</a>";
                }
            }
        ?>
    </form>
</body>
</html>