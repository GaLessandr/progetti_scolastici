<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Aggiungi un nuovo gioco</h2>
<form method="post">
    <div>
        <label>Nome del gioco:</label>
        <input type="text" name = "gioco">
        <?php
            $host = "localhost";
            $username = "root";
            $password = "";
            $db_nome = "torneovg";

            $conn = new mysqli($host, $username, $password, $db_nome);
            if ($conn->connect_errno) {
                echo "Impossibile connetersi al server" . $conn->connect_error . "\n";
                exit;
            }

            if (isset($_POST['gioco'])) {
                $nuovo_gioco = isset($_POST['gioco']) ? $_POST['gioco'] : '';
                $sql = "INSERT INTO giochi (nome)";
                $sql .= " VALUES ('$nuovo_gioco')";
                $result = $conn->query($sql);

                if ($result) {
                    echo "Gioco aggiunto con successo!<br>";
                } else {
                    echo "Errore: " . $sql . "<br>" . $conn->error;
                }
            }
            $conn->close();
            ?>
        <input type="submit" name="Aggiungi" value="Aggiungi">
        </div> 
</form>
</body>
</html>